<?php
require 'db.php';
require 'functions.php';

$error = '';
$step = 1;
$qrUrl = '';
$secret = '';
$email = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!validateCsrfToken($_POST['csrf_token'] ?? '')) {
        $error = 'Invalid security token.';
    } else {
        $name = trim($_POST['name'] ?? '');
        $email = filter_var(trim($_POST['email'] ?? ''), FILTER_SANITIZE_EMAIL);
        $password = $_POST['password'] ?? '';
        $confirm = $_POST['confirm'] ?? '';

        if (strlen($name) < 2 || strlen($name) > 100) {
            $error = 'Name must be 2-100 characters.';
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $error = 'Please enter a valid email.';
        } elseif (strlen($password) < 8) {
            $error = 'Password must be at least 8 characters.';
        } elseif ($password !== $confirm) {
            $error = 'Passwords do not match.';
        } else {
            $check = $pdo->prepare("SELECT id FROM users WHERE email = ?");
            $check->execute([$email]);
            if ($check->fetch()) {
                $error = 'Email already registered.';
            } else {
                $hash = password_hash($password, PASSWORD_DEFAULT);
                $stmt = $pdo->prepare("INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, 'customer')");
                $stmt->execute([$name, $email, $hash]);
                $userId = $pdo->lastInsertId();

                $secret = TOTP::generateSecret();
                $backupCodes = generateBackupCodes();
                $hashedBackups = array_map(fn($c) => password_hash($c, PASSWORD_DEFAULT), $backupCodes);

                $stmt = $pdo->prepare("INSERT INTO otp_secrets (user_id, secret, enabled, backup_codes, verified) VALUES (?, ?, 0, ?, 0)");
                $stmt->execute([$userId, $secret, json_encode($hashedBackups)]);

                $provisioningUri = TOTP::getProvisioningUri($email, $secret);
                $qrUrl = 'https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=' . urlencode($provisioningUri);
                $step = 2;

                $plainBackups = implode(', ', $backupCodes);
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Register | Gourmet Haven</title>
<link rel="stylesheet" href="style.css">
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700&family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
</head>
<body class="auth-page">

<div class="auth-box">
    <?php if ($step === 1): ?>
        <h2>Create Account</h2>
        <?php if ($error): ?><div class="alert alert-error"><?= sanitize($error) ?></div><?php endif; ?>
        <form method="POST">
            <input type="hidden" name="csrf_token" value="<?= generateCsrfToken() ?>">
            <div class="form-group">
                <label>Full Name</label>
                <input type="text" name="name" required>
            </div>
            <div class="form-group">
                <label>Email</label>
                <input type="email" name="email" required>
            </div>
            <div class="form-group">
                <label>Password</label>
                <input type="password" name="password" required minlength="8">
            </div>
            <div class="form-group">
                <label>Confirm Password</label>
                <input type="password" name="confirm" required>
            </div>
            <button type="submit" class="btn-primary full">Register</button>
        </form>
        <p class="text-center mt">Already have an account? <a href="login.php">Login</a></p>

    <?php else: ?>
        <h2>Setup QuickClock 2FA</h2>
        <p>Scan this QR code with Google Authenticator, Authy, or any TOTP app.</p>
        <div class="qr-wrap">
            <img src="<?= sanitize($qrUrl) ?>" alt="2FA QR Code">
        </div>
        <p class="text-center"><strong>Secret:</strong> <?= sanitize($secret) ?></p>
        <div class="backup-codes">
            <h4>Save these backup codes:</h4>
            <p><?= sanitize($plainBackups ?? '') ?></p>
        </div>
        <a href="login.php" class="btn-primary full text-center">Proceed to Login</a>
    <?php endif; ?>
</div>

</body>
</html>
