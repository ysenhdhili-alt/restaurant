<?php
date_default_timezone_set("Africa/Tunis");
require 'db.php';
require 'functions.php';
 
if (!isset($_SESSION['pending_user_id'])) {
    header('Location: login.php');
    exit;
}
 
$error = '';
 
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!validateCsrfToken($_POST['csrf_token'] ?? '')) {
        $error = 'Invalid security token.';
    } else {
        $code = preg_replace('/\s+/', '', $_POST['code'] ?? '');
        $userId = $_SESSION['pending_user_id'];
 
        $stmt = $pdo->prepare("SELECT * FROM email_otps WHERE user_id = ? AND otp_code = ? AND used = 0 AND expires_at > NOW()");
        $stmt->execute([$userId, $code]);
        $otpRecord = $stmt->fetch();
 
        if ($otpRecord) {
            $pdo->prepare("UPDATE email_otps SET used = 1 WHERE id = ?")->execute([$otpRecord['id']]);
 
            // Save role BEFORE unsetting pending vars
            $role = $_SESSION['pending_user_role'];
 
            $_SESSION['user_id']    = $userId;
            $_SESSION['user_name']  = $_SESSION['pending_user_name'];
            $_SESSION['user_email'] = $_SESSION['pending_user_email'];
            $_SESSION['role']       = $role;
 
            unset(
                $_SESSION['pending_user_id'],
                $_SESSION['pending_user_name'],
                $_SESSION['pending_user_email'],
                $_SESSION['pending_user_role']
            );
 
            session_regenerate_id(true);
            header('Location: ' . ($role === 'admin' ? 'dashboard.php' : 'index.php'));
            exit;
        } else {
            $error = 'Invalid or expired code.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Verify Email Code | Gourmet Haven</title>
<link rel="stylesheet" href="style.css">
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700&family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
</head>
<body class="auth-page">
<div class="auth-box">
    <h2>Email Verification</h2>
    <p class="text-center">We sent a 6-digit code to<br><strong><?= sanitize($_SESSION['pending_user_email'] ?? '') ?></strong></p>
    <?php if ($error): ?><div class="alert alert-error"><?= sanitize($error) ?></div><?php endif; ?>
    <form method="POST">
        <input type="hidden" name="csrf_token" value="<?= generateCsrfToken() ?>">
        <div class="form-group">
            <label>6-Digit Code</label>
            <input type="text" name="code" required pattern="[0-9]{6}" maxlength="6" placeholder="123456" autocomplete="off" autofocus style="text-align:center;font-size:24px;letter-spacing:8px;">
        </div>
        <button type="submit" class="btn-primary full">Verify</button>
    </form>
    <p class="text-center mt"><a href="2fa_choice.php">← Back to methods</a></p>
</div>
</body>
</html>