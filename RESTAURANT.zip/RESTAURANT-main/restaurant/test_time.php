<?php
echo "Server Time: " . date('Y-m-d H:i:s') . "<br>";
echo "Unix Timestamp: " . time() . "<br>";
echo "Timezone: " . date_default_timezone_get();
?>