const navToggle = document.getElementById('navToggle');
const navLinks = document.getElementById('navLinks');
if (navToggle) {
    navToggle.addEventListener('click', () => {
        navLinks.classList.toggle('active');
    });
}

let cart = [];
function addToCart(id, name, price) {
    const existing = cart.find(i => i.id === id);
    if (existing) {
        existing.qty++;
    } else {
        cart.push({ id, name, price, qty: 1 });
    }
    updateCartUI();
}

function updateCartUI() {
    const count = cart.reduce((sum, i) => sum + i.qty, 0);
    document.getElementById('cartCount').textContent = count + ' item' + (count !== 1 ? 's' : '');
}

function openCart() {
    const modal = document.getElementById('cartModal');
    const container = document.getElementById('cartItems');
    const totalEl = document.getElementById('cartTotal');
    container.innerHTML = '';
    let total = 0;

    if (cart.length === 0) {
        container.innerHTML = '<p>Your cart is empty.</p>';
    } else {
        cart.forEach((item, idx) => {
            total += item.price * item.qty;
            const div = document.createElement('div');
            div.className = 'cart-item';
            div.innerHTML = `
                <div style="display:flex;justify-content:space-between;padding:8px 0;border-bottom:1px solid #eee;">
                    <span>${item.qty}x ${item.name}</span>
                    <span>$${(item.price * item.qty).toFixed(2)}</span>
                    <button onclick="removeFromCart(${idx})" style="background:none;border:none;color:#dc3545;cursor:pointer;">&times;</button>
                </div>
            `;
            container.appendChild(div);
        });
    }
    totalEl.textContent = total.toFixed(2);
    document.getElementById('itemsJson').value = JSON.stringify(cart);
    modal.style.display = 'flex';
}

function closeCart() {
    document.getElementById('cartModal').style.display = 'none';
}

function removeFromCart(index) {
    cart.splice(index, 1);
    updateCartUI();
    openCart();
}

window.onclick = function(e) {
    const modal = document.getElementById('cartModal');
    if (e.target === modal) closeCart();
};

async function runOCR() {
    const input = document.getElementById('ocrInput');
    const status = document.getElementById('ocrStatus');
    const output = document.getElementById('ocrOutput');

    if (!input.files || !input.files[0]) {
        alert('Please select an image first.');
        return;
    }

    status.textContent = 'Scanning image... please wait.';
    output.value = '';

    try {
        const result = await Tesseract.recognize(input.files[0], 'eng');
        output.value = result.data.text.trim() || 'No text detected.';
        status.textContent = 'Scan complete.';
    } catch (err) {
        console.error(err);
        status.textContent = 'Error during scan.';
        output.value = 'Failed to process image.';
    }
}

function copyOCR() {
    const output = document.getElementById('ocrOutput');
    output.select();
    document.execCommand('copy');
    alert('Text copied to clipboard!');
}

document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function(e) {
        const href = this.getAttribute('href');
        if (href !== '#') {
            e.preventDefault();
            const target = document.querySelector(href);
            if (target) target.scrollIntoView({ behavior: 'smooth' });
        }
    });
});
