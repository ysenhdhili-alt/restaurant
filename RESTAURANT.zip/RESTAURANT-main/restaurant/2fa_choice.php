<?php
date_default_timezone_set("Africa/Tunis");
require 'db.php';
require 'functions.php';
 
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
 
require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';
 
if (!isset($_SESSION['pending_user_id'])) {
    header('Location: login.php');
    exit;
}
 
$userId = $_SESSION['pending_user_id'];
$email  = $_SESSION['pending_user_email'];
 
$hasTOTP = false;
$otpRecord = getUserOtpSecret($pdo, $userId);
if ($otpRecord && !empty($otpRecord['secret'])) {
    $hasTOTP = true;
}
 
$error = '';
 
// === EMAIL OTP ===
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['method'] ?? '') === 'email') {
 
    if (!validateCsrfToken($_POST['csrf_token'] ?? '')) {
        $error = 'Invalid security token.';
    } else {
        $otpCode   = str_pad(random_int(0, 999999), 6, '0', STR_PAD_LEFT);
        $expiresAt = date('Y-m-d H:i:s', strtotime('+10 minutes'));
 
        $pdo->prepare("DELETE FROM email_otps WHERE user_id = ?")->execute([$userId]);
        $stmt = $pdo->prepare("INSERT INTO email_otps (user_id, otp_code, expires_at) VALUES (?, ?, ?)");
        $stmt->execute([$userId, $otpCode, $expiresAt]);
 
        $mail = new PHPMailer(true);
        try {
            $mail->isSMTP();
            $mail->Host       = 'smtp.gmail.com';
            $mail->SMTPAuth   = true;
            $mail->Username   = 'yassineyb024@gmail.com';
            $mail->Password   = 'zzhr qwkt flgw hlve';
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
            $mail->Port       = 587;
            $mail->CharSet    = 'UTF-8';
 
            // Disable SSL verification (fixes certificate errors on localhost)
            $mail->SMTPOptions = [
                'ssl' => [
                    'verify_peer'       => false,
                    'verify_peer_name'  => false,
                    'allow_self_signed' => true,
                ]
            ];
 
            $mail->setFrom('yassineyb024@gmail.com', 'Gourmet Haven');
            $mail->addAddress($email, $_SESSION['pending_user_name']);
            $mail->Subject = 'Your Login Verification Code';
            $mail->Body    = "Hello " . $_SESSION['pending_user_name'] . ",\n\nYour verification code is: $otpCode\n\nThis code expires in 10 minutes.\n\nIf you did not request this, ignore this email.";
 
            if ($mail->send()) {
                header('Location: verify_email_otp.php');
                exit;
            } else {
                $error = 'Could not send email: ' . $mail->ErrorInfo;
            }
        } catch (Exception $e) {
            $error = 'Could not send email: ' . $mail->ErrorInfo;
        }
    }
}
 
// === TOTP ===
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['method'] ?? '') === 'totp') {
    header('Location: verify_2fa.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Choose 2FA | Gourmet Haven</title>
<link rel="stylesheet" href="style.css">
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700&family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
</head>
<body class="auth-page">
<div class="auth-box">
    <h2>Verify Your Identity</h2>
    <p class="text-center">Choose your preferred authentication method.</p>
 
    <?php if ($error): ?><div class="alert alert-error"><?= sanitize($error) ?></div><?php endif; ?>
 
    <?php if ($hasTOTP): ?>
    <form method="POST" style="margin-bottom:15px;">
        <input type="hidden" name="csrf_token" value="<?= generateCsrfToken() ?>">
        <input type="hidden" name="method" value="totp">
        <button type="submit" class="btn-primary full" style="padding:16px;">
            📱 QuickClock (Authenticator App)
        </button>
    </form>
    <?php endif; ?>
 
    <form method="POST">
        <input type="hidden" name="csrf_token" value="<?= generateCsrfToken() ?>">
        <input type="hidden" name="method" value="email">
        <button type="submit" class="btn-secondary full" style="padding:16px;">
            📧 Send Code to Gmail
        </button>
    </form>
</div>
</body>
</html>