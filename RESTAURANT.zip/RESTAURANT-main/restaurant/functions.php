<?php
require_once 'db.php';

class TOTP {
    private static $base32Chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';

    public static function generateSecret($length = 32) {
        $chars = self::$base32Chars;
        $secret = '';
        for ($i = 0; $i < $length; $i++) {
            $secret .= $chars[random_int(0, 31)];
        }
        return $secret;
    }

    private static function base32Decode($secret) {
        $map = array_flip(str_split(self::$base32Chars));
        $secret = strtoupper(str_replace('=', '', $secret));
        $binary = '';
        $buffer = 0;
        $bufferSize = 0;
        for ($i = 0; $i < strlen($secret); $i++) {
            $char = $secret[$i];
            if (!isset($map[$char])) continue;
            $buffer = ($buffer << 5) | $map[$char];
            $bufferSize += 5;
            if ($bufferSize >= 8) {
                $bufferSize -= 8;
                $binary .= chr(($buffer >> $bufferSize) & 0xFF);
            }
        }
        return $binary;
    }

    public static function getCode($secret, $timeSlice = null) {
        if ($timeSlice === null) {
            $timeSlice = floor(time() / 30);
        }
        $secretKey = self::base32Decode($secret);
        $time = pack('N', 0) . pack('N', $timeSlice);
        $hm = hash_hmac('sha1', $time, $secretKey, true);
        $offset = ord(substr($hm, -1)) & 0x0F;
        $code = (
            ((ord($hm[$offset]) & 0x7F) << 24) |
            ((ord($hm[$offset + 1]) & 0xFF) << 16) |
            ((ord($hm[$offset + 2]) & 0xFF) << 8) |
            (ord($hm[$offset + 3]) & 0xFF)
        ) % 1000000;
        return str_pad((string)$code, 6, '0', STR_PAD_LEFT);
    }

    public static function verifyCode($secret, $code, $window = 1) {
        $timeSlice = floor(time() / 30);
        for ($i = -$window; $i <= $window; $i++) {
            if (hash_equals(self::getCode($secret, $timeSlice + $i), $code)) {
                return true;
            }
        }
        return false;
    }

    public static function getProvisioningUri($label, $secret, $issuer = 'QuiClock Restaurant') {
        return 'otpauth://totp/' . rawurlencode($issuer . ':' . $label)
            . '?secret=' . $secret
            . '&issuer=' . rawurlencode($issuer);
    }
}

function generateBackupCodes() {
    $codes = [];
    for ($i = 0; $i < 5; $i++) {
        $codes[] = strtoupper(bin2hex(random_bytes(4)));
    }
    return $codes;
}

function checkOtpRateLimit() {
    if (!isset($_SESSION['otp_attempts'])) $_SESSION['otp_attempts'] = 0;
    if (!isset($_SESSION['otp_last_attempt'])) $_SESSION['otp_last_attempt'] = 0;

    if ($_SESSION['otp_attempts'] >= 5) {
        if (time() - $_SESSION['otp_last_attempt'] < 300) {
            return false;
        }
        $_SESSION['otp_attempts'] = 0;
    }
    return true;
}

function recordOtpAttempt() {
    $_SESSION['otp_attempts'] = ($_SESSION['otp_attempts'] ?? 0) + 1;
    $_SESSION['otp_last_attempt'] = time();
}

function getUserOtpSecret($pdo, $userId) {
    $stmt = $pdo->prepare("SELECT * FROM otp_secrets WHERE user_id = ?");
    $stmt->execute([$userId]);
    return $stmt->fetch();
}
