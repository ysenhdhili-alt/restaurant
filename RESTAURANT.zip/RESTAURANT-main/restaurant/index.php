<?php
require 'db.php';
$success = $error = '';
 
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['form_type']) && $_POST['form_type'] === 'reservation') {
    if (!validateCsrfToken($_POST['csrf_token'] ?? '')) { $error = 'Invalid security token.'; }
    else {
        $name=trim($_POST['name']??''); $email=filter_var(trim($_POST['email']??''),FILTER_SANITIZE_EMAIL);
        $phone=trim($_POST['phone']??''); $date=$_POST['date']??''; $time=$_POST['time']??'';
        $guests=filter_var($_POST['guests']??1,FILTER_VALIDATE_INT); $notes=trim($_POST['notes']??'');
        $userId=isLoggedIn()?$_SESSION['user_id']:null;
        if($name&&$email&&$date&&$time&&$guests){
            $stmt=$pdo->prepare("INSERT INTO reservations (user_id,name,email,phone,reservation_date,reservation_time,guests,notes) VALUES (?,?,?,?,?,?,?,?)");
            $stmt->execute([$userId,$name,$email,$phone,$date,$time,$guests,$notes]);
            $success='Reservation request submitted successfully!';
        } else { $error='Please fill all required reservation fields.'; }
    }
}
 
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['form_type']) && $_POST['form_type'] === 'order') {
    if (!validateCsrfToken($_POST['csrf_token'] ?? '')) { $error = 'Invalid security token.'; }
    else {
        $itemsJson=$_POST['items_json']??'[]'; $items=json_decode($itemsJson,true);
        if(!empty($items)&&is_array($items)){
            $total=0; foreach($items as $it) $total+=($it['price']*($it['qty']??1));
            $custName=isLoggedIn()?$_SESSION['user_name']:trim($_POST['customer_name']??'Guest');
            $custEmail=isLoggedIn()?$_SESSION['user_email']:trim($_POST['customer_email']??'');
            $userId=isLoggedIn()?$_SESSION['user_id']:null;
            $stmt=$pdo->prepare("INSERT INTO orders (user_id,customer_name,customer_email,items_json,total_amount) VALUES (?,?,?,?,?)");
            $stmt->execute([$userId,$custName,$custEmail,$itemsJson,$total]);
            $success='Order placed! We will prepare your food shortly.';
        } else { $error='Your cart is empty.'; }
    }
}
 
$categories=$pdo->query("SELECT DISTINCT category FROM menu_items WHERE available=1 ORDER BY category")->fetchAll(PDO::FETCH_COLUMN);
$menuItems=$pdo->query("SELECT * FROM menu_items WHERE available=1 ORDER BY category,name")->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Gourmet Haven | Fine Dining · Sousse</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,700;1,400;1,700&family=DM+Sans:wght@200;300;400;500&family=Cinzel:wght@400;600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css"/>
<style>
/* ─── RESET & ROOT ───────────────────────────────────────── */
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
:root{
  --gold:#c9a84c;
  --gold2:#e8c97a;
  --gold-dim:rgba(201,168,76,.18);
  --obsidian:#060504;
  --carbon:#0d0b09;
  --onyx:#141210;
  --graphite:#1e1b16;
  --ash:#2a2620;
  --cream:#f0e6d3;
  --dust:#9a8e7e;
  --mist:#c8bfb2;
  --serif:'Playfair Display',serif;
  --display:'Cinzel',serif;
  --sans:'DM Sans',sans-serif;
  --ease:cubic-bezier(.22,.61,.36,1);
  --ease2:cubic-bezier(.16,1,.3,1);
}
html{scroll-behavior:smooth;font-size:16px}
body{background:var(--obsidian);color:var(--mist);font-family:var(--sans);font-weight:300;overflow-x:hidden;cursor:none}
 
/* ─── CUSTOM CURSOR ──────────────────────────────────────── */
.cursor{position:fixed;top:0;left:0;pointer-events:none;z-index:9999;mix-blend-mode:difference}
.cursor-dot{width:6px;height:6px;background:var(--gold);border-radius:50%;transform:translate(-50%,-50%);transition:transform .1s}
.cursor-ring{width:36px;height:36px;border:1px solid rgba(201,168,76,.5);border-radius:50%;transform:translate(-50%,-50%);transition:transform .18s var(--ease),width .25s,height .25s,opacity .25s}
body:hover .cursor-ring{opacity:1}
.cursor-ring.hovered{width:56px;height:56px;border-color:var(--gold)}
 
/* ─── NOISE OVERLAY ──────────────────────────────────────── */
body::before{
  content:'';position:fixed;inset:0;z-index:1000;pointer-events:none;opacity:.028;
  background-image:url("data:image/svg+xml,%3Csvg viewBox='0 0 512 512' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.75' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)'/%3E%3C/svg%3E");
}
 
/* ─── NAV ────────────────────────────────────────────────── */
nav{
  position:fixed;top:0;left:0;right:0;z-index:200;
  display:flex;align-items:center;justify-content:space-between;
  padding:1.6rem 4rem;
  transition:all .5s var(--ease);
}
nav.scrolled{
  background:rgba(6,5,4,.88);
  backdrop-filter:blur(20px);
  -webkit-backdrop-filter:blur(20px);
  padding:1rem 4rem;
  border-bottom:1px solid rgba(201,168,76,.08);
}
.logo{
  font-family:var(--display);font-size:1.25rem;font-weight:600;
  color:var(--gold);letter-spacing:.18em;text-decoration:none;
  display:flex;align-items:center;gap:.7rem;
}
.logo-mark{
  width:32px;height:32px;border:1px solid var(--gold);border-radius:50%;
  display:flex;align-items:center;justify-content:center;
  font-size:.55rem;color:var(--gold);letter-spacing:.08em;opacity:.8;
}
.nav-links{display:flex;gap:2.4rem;list-style:none;align-items:center}
.nav-links a{
  color:var(--dust);text-decoration:none;
  font-size:.72rem;letter-spacing:.2em;text-transform:uppercase;
  transition:color .3s;position:relative;
}
.nav-links a::after{
  content:'';position:absolute;bottom:-.2rem;left:0;width:0;height:1px;
  background:var(--gold);transition:width .35s var(--ease);
}
.nav-links a:hover{color:var(--gold)}
.nav-links a:hover::after{width:100%}
.btn-nav{
  border:1px solid rgba(201,168,76,.4)!important;color:var(--gold)!important;
  padding:.38rem 1.1rem!important;border-radius:0!important;
}
.btn-nav:hover{background:var(--gold)!important;color:var(--obsidian)!important}
.btn-nav:hover::after{width:0!important}
.nav-toggle{display:none;background:none;border:none;color:var(--cream);font-size:1.4rem;cursor:pointer}
 
/* ─── HERO ───────────────────────────────────────────────── */
.hero{
  position:relative;height:100vh;min-height:700px;
  display:flex;align-items:center;justify-content:center;
  text-align:center;overflow:hidden;
}
.hero-video{
  position:absolute;inset:0;width:100%;height:100%;
  object-fit:cover;object-position:center;z-index:0;
}
.hero-overlay{
  position:absolute;inset:0;z-index:1;
  background:
    linear-gradient(to bottom, rgba(6,5,4,.72) 0%, rgba(6,5,4,.38) 40%, rgba(6,5,4,.55) 70%, rgba(6,5,4,.92) 100%),
    radial-gradient(ellipse 70% 50% at 50% 50%, transparent 0%, rgba(6,5,4,.5) 100%);
}
.hero-vignette{
  position:absolute;inset:0;z-index:2;pointer-events:none;
  background:radial-gradient(ellipse 100% 100% at 50% 50%, transparent 50%, rgba(6,5,4,.6) 100%);
}
.hero-content{position:relative;z-index:3;max-width:860px;padding:2rem}
.hero-badge{
  display:inline-flex;align-items:center;gap:.8rem;
  font-size:.65rem;letter-spacing:.3em;text-transform:uppercase;
  color:var(--gold);margin-bottom:2rem;
  opacity:0;animation:riseIn 1s var(--ease2) .4s forwards;
}
.hero-badge::before,.hero-badge::after{content:'';width:30px;height:1px;background:var(--gold);opacity:.5}
.hero-title{
  font-family:var(--serif);font-size:clamp(3.5rem,8vw,7rem);
  font-weight:400;line-height:.96;letter-spacing:-.02em;
  color:var(--cream);margin-bottom:1rem;
  opacity:0;animation:riseIn 1.1s var(--ease2) .65s forwards;
}
.hero-title em{font-style:italic;color:var(--gold);display:block}
.hero-sub{
  font-size:.95rem;color:var(--dust);letter-spacing:.08em;line-height:1.8;
  margin-bottom:3rem;max-width:520px;margin-left:auto;margin-right:auto;
  opacity:0;animation:riseIn 1s var(--ease2) .85s forwards;
}
.hero-ctas{
  display:flex;gap:1.2rem;justify-content:center;flex-wrap:wrap;
  opacity:0;animation:riseIn .9s var(--ease2) 1.05s forwards;
}
.btn-ghost{
  display:inline-flex;align-items:center;gap:.6rem;
  border:1px solid rgba(201,168,76,.35);color:var(--cream);
  text-decoration:none;padding:.7rem 2rem;
  font-family:var(--sans);font-size:.72rem;letter-spacing:.2em;text-transform:uppercase;
  transition:all .4s var(--ease);position:relative;overflow:hidden;
}
.btn-ghost::before{
  content:'';position:absolute;inset:0;background:rgba(201,168,76,.08);
  transform:scaleX(0);transform-origin:left;transition:transform .4s var(--ease);
}
.btn-ghost:hover{border-color:var(--gold);color:var(--gold)}
.btn-ghost:hover::before{transform:scaleX(1)}
.btn-gold{
  display:inline-flex;align-items:center;gap:.6rem;
  background:var(--gold);color:var(--obsidian);
  text-decoration:none;padding:.7rem 2rem;
  font-family:var(--sans);font-size:.72rem;letter-spacing:.2em;text-transform:uppercase;font-weight:500;
  transition:all .35s var(--ease);
}
.btn-gold:hover{background:var(--gold2);transform:translateY(-2px);box-shadow:0 12px 40px rgba(201,168,76,.25)}
.hero-scroll-hint{
  position:absolute;bottom:2.5rem;left:50%;transform:translateX(-50%);
  z-index:3;display:flex;flex-direction:column;align-items:center;gap:.6rem;
  opacity:0;animation:fadeIn 1s ease 1.6s forwards;
}
.hero-scroll-hint span{font-size:.6rem;letter-spacing:.25em;text-transform:uppercase;color:var(--dust)}
.scroll-pulse{width:1px;height:48px;background:linear-gradient(to bottom,var(--gold) 0%,transparent 100%);animation:pulse 2.5s ease-in-out infinite}
 
/* ─── ALERTS ─────────────────────────────────────────────── */
.alert{padding:1rem 2rem;max-width:860px;margin:1.5rem auto;font-size:.84rem;border-left:2px solid}
.alert-success{border-color:var(--gold);background:rgba(201,168,76,.06);color:var(--gold2)}
.alert-error{border-color:#b44;background:rgba(180,68,68,.06);color:#e08080}
 
/* ─── SECTIONS ───────────────────────────────────────────── */
.section{padding:9rem 4rem}
.container{max-width:1280px;margin:0 auto}
.section-label{
  display:flex;align-items:center;gap:1rem;justify-content:center;
  font-size:.64rem;letter-spacing:.3em;text-transform:uppercase;
  color:var(--gold);margin-bottom:1.2rem;
}
.section-label::before,.section-label::after{content:'';flex:0 0 24px;height:1px;background:var(--gold);opacity:.4}
.section-title{
  font-family:var(--serif);font-size:clamp(2.2rem,4.5vw,3.8rem);
  font-weight:400;color:var(--cream);text-align:center;line-height:1.1;margin-bottom:.6rem;
}
.section-title em{font-style:italic;color:var(--gold)}
.ornament{
  display:flex;align-items:center;justify-content:center;gap:.8rem;
  margin:1.4rem auto 3.5rem;
}
.ornament::before,.ornament::after{content:'';flex:0 0 40px;height:1px;background:var(--gold);opacity:.25}
.ornament-diamond{width:6px;height:6px;background:var(--gold);transform:rotate(45deg);opacity:.7}
 
/* ─── MENU ───────────────────────────────────────────────── */
#menu{background:var(--carbon);position:relative;overflow:hidden}
#menu::before{
  content:'';position:absolute;top:-300px;right:-300px;
  width:800px;height:800px;border-radius:50%;
  background:radial-gradient(circle,rgba(201,168,76,.04) 0%,transparent 70%);
  pointer-events:none;
}
.cart-float{
  position:sticky;top:76px;z-index:50;
  display:flex;align-items:center;justify-content:space-between;
  background:rgba(14,12,9,.9);backdrop-filter:blur(16px);
  border:1px solid rgba(201,168,76,.1);
  padding:.9rem 1.8rem;margin-bottom:3.5rem;
}
#cartCount{font-size:.75rem;letter-spacing:.12em;color:var(--gold);font-weight:400}
.menu-cat-title{
  font-family:var(--serif);font-size:1.7rem;font-weight:400;font-style:italic;
  color:var(--cream);margin-bottom:2rem;
  display:flex;align-items:center;gap:1.2rem;
}
.menu-cat-title::after{content:'';flex:1;height:1px;background:linear-gradient(to right,rgba(201,168,76,.2),transparent)}
.menu-grid{
  display:grid;
  grid-template-columns:repeat(auto-fill,minmax(300px,1fr));
  gap:1px;background:rgba(201,168,76,.06);
  margin-bottom:5rem;
}
.menu-card{
  background:var(--carbon);
  display:flex;flex-direction:column;
  transition:background .35s;
  position:relative;overflow:hidden;
}
.menu-card::after{
  content:'';position:absolute;inset:0;
  background:linear-gradient(135deg,rgba(201,168,76,.04) 0%,transparent 60%);
  opacity:0;transition:opacity .35s;pointer-events:none;
}
.menu-card:hover{background:var(--onyx)}
.menu-card:hover::after{opacity:1}
.menu-img-wrap{position:relative;overflow:hidden;aspect-ratio:16/10}
.menu-img-wrap img,.menu-img-placeholder{
  width:100%;height:100%;object-fit:cover;display:block;
  transition:transform .6s var(--ease);
}
.menu-card:hover .menu-img-wrap img{transform:scale(1.04)}
.menu-img-placeholder{
  display:flex;align-items:center;justify-content:center;
  background:var(--graphite);
  font-family:var(--display);font-size:.7rem;letter-spacing:.2em;
  color:var(--ash);text-transform:uppercase;
}
.menu-body{padding:1.4rem 1.6rem 1.8rem;flex:1;display:flex;flex-direction:column}
.menu-body h4{
  font-family:var(--serif);font-size:1.15rem;font-weight:400;
  color:var(--cream);margin-bottom:.5rem;
}
.menu-body p{
  font-size:.82rem;color:var(--dust);line-height:1.7;flex:1;margin-bottom:1.2rem;
}
.menu-foot{display:flex;align-items:center;justify-content:space-between}
.price{font-family:var(--serif);font-size:1.3rem;color:var(--gold)}
.btn-add{
  background:none;border:1px solid rgba(201,168,76,.3);color:var(--gold);
  padding:.35rem 1.1rem;font-family:var(--sans);font-size:.68rem;letter-spacing:.15em;
  text-transform:uppercase;cursor:pointer;transition:all .3s;
}
.btn-add:hover{background:var(--gold);color:var(--obsidian)}
 
/* ─── RESERVATION ────────────────────────────────────────── */
#reservation{
  background:var(--onyx);position:relative;overflow:hidden;
}
#reservation::before{
  content:'RESERVE';
  position:absolute;right:-2rem;bottom:-3rem;
  font-family:var(--display);font-size:12rem;font-weight:600;
  color:rgba(201,168,76,.03);pointer-events:none;letter-spacing:-.04em;white-space:nowrap;
}
.res-layout{
  display:grid;grid-template-columns:1fr 1.4fr;gap:6rem;
  align-items:start;max-width:1100px;margin:0 auto;
}
.res-aside h3{
  font-family:var(--serif);font-size:2.2rem;font-weight:400;font-style:italic;
  color:var(--cream);line-height:1.2;margin-bottom:1.5rem;
}
.res-aside p{color:var(--dust);font-size:.9rem;line-height:1.9;margin-bottom:2rem}
.res-details{display:flex;flex-direction:column;gap:1.2rem}
.res-detail-item{display:flex;gap:.9rem;align-items:flex-start}
.res-detail-icon{
  width:28px;height:28px;border:1px solid rgba(201,168,76,.25);
  flex-shrink:0;display:flex;align-items:center;justify-content:center;
  font-size:.85rem;color:var(--gold);margin-top:.1rem;
}
.res-detail-item h5{font-size:.72rem;letter-spacing:.15em;text-transform:uppercase;color:var(--gold);margin-bottom:.25rem}
.res-detail-item p{font-size:.85rem;color:var(--dust);line-height:1.7;margin:0}
.form-panel{background:var(--graphite);border:1px solid rgba(201,168,76,.08);padding:2.5rem}
.form-row{display:grid;grid-template-columns:1fr 1fr;gap:0}
.field{padding:1.2rem 1.4rem;border-bottom:1px solid rgba(201,168,76,.07);border-right:1px solid rgba(201,168,76,.07)}
.field:nth-child(even){border-right:none}
.field.full{grid-column:1/-1;border-right:none}
.field label{display:block;font-size:.65rem;letter-spacing:.18em;text-transform:uppercase;color:var(--dust);margin-bottom:.5rem}
.field input,.field textarea{
  width:100%;background:transparent;border:none;
  color:var(--cream);font-family:var(--sans);font-size:.92rem;outline:none;
  border-bottom:1px solid rgba(201,168,76,.18);padding:.4rem 0;
  transition:border-color .3s;
}
.field input:focus,.field textarea:focus{border-color:var(--gold)}
.field textarea{resize:none;line-height:1.7}
input[type="date"]::-webkit-calendar-picker-indicator{filter:invert(.5) sepia(1) saturate(3) hue-rotate(10deg)}
.submit-field{padding:1.8rem 1.4rem;grid-column:1/-1;border:none}
.btn-submit{
  width:100%;background:var(--gold);color:var(--obsidian);
  border:none;padding:1.1rem;cursor:pointer;
  font-family:var(--display);font-size:.72rem;letter-spacing:.25em;text-transform:uppercase;font-weight:600;
  transition:all .35s var(--ease);
}
.btn-submit:hover{background:var(--gold2);box-shadow:0 8px 32px rgba(201,168,76,.22);transform:translateY(-1px)}
 
/* ─── MAP SECTION ────────────────────────────────────────── */
#location{background:var(--carbon);padding:0;position:relative}
.map-wrap{display:grid;grid-template-columns:1fr 1.8fr}
.map-info{
  background:var(--obsidian);padding:6rem 4rem;
  display:flex;flex-direction:column;justify-content:center;
  border-right:1px solid rgba(201,168,76,.08);
}
.map-info .section-label{justify-content:flex-start}
.map-info .section-label::after{display:none}
.map-info h2{
  font-family:var(--serif);font-size:clamp(2rem,3.5vw,3rem);
  font-weight:400;color:var(--cream);line-height:1.15;margin:1rem 0 2rem;
}
.map-info h2 em{font-style:italic;color:var(--gold)}
.map-info-list{display:flex;flex-direction:column;gap:1.6rem}
.map-info-item{display:flex;gap:1rem;align-items:flex-start}
.map-icon{
  width:36px;height:36px;flex-shrink:0;
  border:1px solid rgba(201,168,76,.2);
  display:flex;align-items:center;justify-content:center;
  font-size:1rem;
}
.map-icon-inner h5{font-size:.68rem;letter-spacing:.18em;text-transform:uppercase;color:var(--gold);margin-bottom:.3rem}
.map-icon-inner p{font-size:.85rem;color:var(--dust);line-height:1.7}
.map-icon-inner a{color:var(--dust);text-decoration:none;transition:color .3s}
.map-icon-inner a:hover{color:var(--gold)}
#soussemap{height:560px;width:100%;filter:grayscale(.3) brightness(.85)}
 
/* Leaflet custom styles */
.leaflet-container{background:var(--carbon)!important}
.leaflet-tile{filter:grayscale(.5) brightness(.7) hue-rotate(15deg) saturate(.8)!important}
.leaflet-popup-content-wrapper{
  background:var(--onyx)!important;border:1px solid rgba(201,168,76,.2)!important;
  border-radius:0!important;box-shadow:0 8px 32px rgba(0,0,0,.5)!important;
}
.leaflet-popup-content{color:var(--cream)!important;font-family:var(--sans)!important;font-size:.85rem!important}
.leaflet-popup-tip-container{display:none}
.map-marker-label{font-family:var(--display);font-size:.7rem;letter-spacing:.15em;color:var(--obsidian);padding:.2rem .5rem;background:var(--gold);font-weight:600}
 
/* ─── OCR ────────────────────────────────────────────────── */
#ocr{background:var(--onyx)}
.ocr-box{max-width:700px;margin:0 auto}
.ocr-drop{
  border:1px dashed rgba(201,168,76,.25);padding:3rem 2rem;
  text-align:center;cursor:pointer;transition:all .3s;margin-bottom:1.5rem;
  position:relative;overflow:hidden;
}
.ocr-drop:hover,.ocr-drop.drag{border-color:var(--gold);background:rgba(201,168,76,.04)}
.ocr-drop-icon{font-size:2rem;margin-bottom:.8rem;opacity:.4}
.ocr-drop p{font-size:.82rem;color:var(--dust);letter-spacing:.08em}
.ocr-drop input{position:absolute;inset:0;opacity:0;cursor:pointer}
.ocr-controls{display:flex;gap:1rem;margin-bottom:1rem}
.ocr-status{font-size:.78rem;color:var(--gold);letter-spacing:.08em;min-height:1.2rem;margin-bottom:.8rem}
#ocrOutput{
  width:100%;background:var(--graphite);border:1px solid rgba(201,168,76,.1);
  color:var(--cream);font-family:var(--sans);font-size:.88rem;
  padding:1.2rem;resize:vertical;line-height:1.8;outline:none;min-height:120px;
}
#ocrOutput:focus{border-color:rgba(201,168,76,.3)}
.btn-outline{
  background:none;border:1px solid rgba(201,168,76,.25);color:var(--dust);
  padding:.5rem 1.4rem;font-family:var(--sans);font-size:.72rem;letter-spacing:.15em;
  text-transform:uppercase;cursor:pointer;transition:all .3s;
}
.btn-outline:hover{border-color:var(--gold);color:var(--gold)}
 
/* ─── FOOTER ─────────────────────────────────────────────── */
footer{
  background:var(--obsidian);border-top:1px solid rgba(201,168,76,.07);
  padding:3rem 4rem;
}
.footer-inner{
  max-width:1280px;margin:0 auto;
  display:flex;justify-content:space-between;align-items:center;
}
.footer-logo{
  font-family:var(--display);font-size:1rem;letter-spacing:.2em;color:var(--gold);
  text-decoration:none;
}
footer p{font-size:.72rem;color:var(--dust);letter-spacing:.1em}
 
/* ─── MODAL ──────────────────────────────────────────────── */
.modal{
  display:none;position:fixed;inset:0;z-index:500;
  background:rgba(0,0,0,.8);backdrop-filter:blur(10px);
  align-items:center;justify-content:center;
}
.modal.open{display:flex}
.modal-box{
  background:var(--onyx);border:1px solid rgba(201,168,76,.15);
  width:90%;max-width:540px;max-height:88vh;overflow-y:auto;padding:2.5rem;
  animation:riseIn .4s var(--ease2);
}
.modal-box h2{
  font-family:var(--serif);font-size:1.8rem;font-weight:400;
  color:var(--cream);margin-bottom:1.8rem;
}
.modal-close{
  float:right;background:none;border:none;
  color:var(--dust);font-size:1.5rem;cursor:pointer;
  margin-top:-.3rem;transition:color .3s;
}
.modal-close:hover{color:var(--gold)}
#cartItems{margin-bottom:1.5rem;display:flex;flex-direction:column;gap:.6rem}
.cart-item{
  display:flex;justify-content:space-between;align-items:center;
  padding:.75rem 0;border-bottom:1px solid rgba(201,168,76,.08);font-size:.88rem;
}
.cart-item-name{color:var(--mist)}
.cart-item-qty{color:var(--dust);margin-left:.4rem;font-size:.8rem}
.cart-r{display:flex;align-items:center;gap:1rem}
.cart-price{font-family:var(--serif);color:var(--gold)}
.cart-rm{
  background:none;border:none;color:var(--dust);cursor:pointer;
  font-size:1rem;transition:color .3s;padding:.2rem .3rem;
}
.cart-rm:hover{color:#c07070}
.cart-total-row{
  text-align:right;font-family:var(--serif);font-size:1.35rem;
  color:var(--gold);padding-top:.9rem;border-top:1px solid rgba(201,168,76,.15);margin-bottom:1.8rem;
}
#orderForm{display:flex;flex-direction:column;gap:1rem}
.oc{
  background:transparent;border:none;border-bottom:1px solid rgba(201,168,76,.2);
  color:var(--cream);font-family:var(--sans);padding:.5rem 0;outline:none;font-size:.9rem;transition:border-color .3s;
}
.oc:focus{border-color:var(--gold)}
#orderForm .btn-gold{border:none;width:100%;justify-content:center;padding:1rem;font-size:.75rem;margin-top:.5rem}
 
/* ─── ANIMATIONS ─────────────────────────────────────────── */
@keyframes riseIn{from{opacity:0;transform:translateY(32px)}to{opacity:1;transform:translateY(0)}}
@keyframes fadeIn{from{opacity:0}to{opacity:1}}
@keyframes pulse{0%,100%{opacity:.3;transform:scaleY(.8)}50%{opacity:1;transform:scaleY(1)}}
.reveal{opacity:0;transform:translateY(32px);transition:opacity .9s var(--ease2),transform .9s var(--ease2)}
.reveal.visible{opacity:1;transform:translateY(0)}
.reveal-delay-1{transition-delay:.1s}
.reveal-delay-2{transition-delay:.2s}
.reveal-delay-3{transition-delay:.3s}
 
/* ─── RESPONSIVE ─────────────────────────────────────────── */
@media(max-width:1024px){
  .res-layout{grid-template-columns:1fr;gap:3rem}
  .map-wrap{grid-template-columns:1fr}
  #soussemap{height:380px}
  .map-info{padding:4rem 2rem}
}
@media(max-width:768px){
  nav{padding:1rem 1.5rem}
  nav.scrolled{padding:.8rem 1.5rem}
  .nav-toggle{display:block}
  .nav-links{
    display:none;position:fixed;inset:0;
    background:rgba(6,5,4,.97);backdrop-filter:blur(16px);
    flex-direction:column;justify-content:center;align-items:center;gap:2.5rem;
    z-index:300;
  }
  .nav-links.open{display:flex}
  .section{padding:5rem 1.5rem}
  .form-row{grid-template-columns:1fr}
  .field:nth-child(even){border-right:1px solid rgba(201,168,76,.07)}
  .hero-title{font-size:3rem}
  .footer-inner{flex-direction:column;gap:1rem;text-align:center}
}
</style>
</head>
<body>
 
<!-- CURSOR -->
<div class="cursor" id="cursor">
  <div class="cursor-ring" id="cursorRing"></div>
  <div class="cursor-dot" id="cursorDot"></div>
</div>
 
<!-- NAV -->
<nav id="navbar">
  <a href="index.php" class="logo">
    <div class="logo-mark">GH</div>
    Gourmet Haven
  </a>
  <button class="nav-toggle" id="navToggle">&#9776;</button>
  <ul class="nav-links" id="navLinks">
    <li><a href="#menu">Menu</a></li>
    <li><a href="#reservation">Reserve</a></li>
    <li><a href="#location">Location</a></li>
    <li><a href="#ocr">Scan</a></li>
    <?php if(isLoggedIn()): ?>
      <?php if(isAdmin()): ?><li><a href="dashboard.php">Dashboard</a></li><?php endif; ?>
      <li><a href="logout.php">Logout</a></li>
    <?php else: ?>
      <li><a href="login.php">Login</a></li>
      <li><a href="register.php" class="btn-nav">Register</a></li>
    <?php endif; ?>
  </ul>
</nav>
 
<!-- HERO with VIDEO -->
<header class="hero">
  <video class="hero-video" autoplay muted loop playsinline
    src="Gen-4_Turbo_-_Ultra-photoreal_cinematic_food_scene_of_an_artisan_pizza_on_a_dark_wet_marble_slab_ins__online-video-cutter_com_.mp4"
    poster="">
  </video>
  <div class="hero-overlay"></div>
  <div class="hero-vignette"></div>
  <div class="hero-content">
    <div class="hero-badge">Est. 2008 &nbsp;&bull;&nbsp; Sousse, Tunisia</div>
    <h1 class="hero-title">
      Where Every Dish<br><em>Tells a Story</em>
    </h1>
    <p class="hero-sub">An intimate journey through Mediterranean flavours, crafted with passion and presented with artistry.</p>
    <div class="hero-ctas">
      <a href="#menu" class="btn-gold">Explore Menu</a>
      <a href="#reservation" class="btn-ghost">Reserve a Table</a>
    </div>
  </div>
  <div class="hero-scroll-hint">
    <span>Scroll to discover</span>
    <div class="scroll-pulse"></div>
  </div>
</header>
 
<?php if($success):?><div class="alert alert-success container"><?=htmlspecialchars($success)?></div><?php endif;?>
<?php if($error):?><div class="alert alert-error container"><?=htmlspecialchars($error)?></div><?php endif;?>
 
<!-- MENU -->
<section id="menu" class="section">
  <div class="container">
    <div class="reveal">
      <div class="section-label">Crafted With Purpose</div>
      <h2 class="section-title">Our <em>Menu</em></h2>
      <div class="ornament"><div class="ornament-diamond"></div></div>
    </div>
    <div class="cart-float">
      <span id="cartCount">0 items in cart</span>
      <button class="btn-gold" onclick="openCart()">View Cart</button>
    </div>
    <?php foreach($categories as $cat):?>
    <div class="reveal">
      <h3 class="menu-cat-title"><?=htmlspecialchars($cat)?></h3>
      <div class="menu-grid">
        <?php foreach($menuItems as $item): if($item['category']===$cat):?>
        <div class="menu-card">
          <div class="menu-img-wrap">
            <?php if($item['image_path']):?>
              <img src="<?=htmlspecialchars($item['image_path'])?>" alt="<?=htmlspecialchars($item['name'])?>" loading="lazy">
            <?php else:?><div class="menu-img-placeholder">Gourmet Haven</div><?php endif;?>
          </div>
          <div class="menu-body">
            <h4><?=htmlspecialchars($item['name'])?></h4>
            <p><?=htmlspecialchars($item['description']??'')?></p>
            <div class="menu-foot">
              <span class="price">$<?=number_format($item['price'],2)?></span>
              <button class="btn-add" onclick="addToCart(<?=$item['id']?>,'<?=addslashes(htmlspecialchars($item['name']))?>',<?=$item['price']?>)">Add</button>
            </div>
          </div>
        </div>
        <?php endif; endforeach;?>
      </div>
    </div>
    <?php endforeach;?>
  </div>
</section>
 
<!-- RESERVATION -->
<section id="reservation" class="section">
  <div class="container">
    <div class="reveal">
      <div class="section-label">Your Table Awaits</div>
      <h2 class="section-title"><em>Reserve</em> a Table</h2>
      <div class="ornament"><div class="ornament-diamond"></div></div>
    </div>
    <div class="res-layout reveal">
      <div class="res-aside">
        <h3>An Evening of Pure Indulgence</h3>
        <p>Reserve your place at Gourmet Haven and let us craft an unforgettable evening for you. Every table is a stage for our culinary artistry.</p>
        <div class="res-details">
          <div class="res-detail-item">
            <div class="res-detail-icon">📍</div>
            <div>
              <h5>Address</h5>
              <p>Avenue Habib Bourguiba<br>Sousse 4000, Tunisia</p>
            </div>
          </div>
          <div class="res-detail-item">
            <div class="res-detail-icon">🕐</div>
            <div>
              <h5>Opening Hours</h5>
              <p>Every Day: 11:00 – 23:00<br>Kitchen closes at 22:30</p>
            </div>
          </div>
          <div class="res-detail-item">
            <div class="res-detail-icon">📞</div>
            <div>
              <h5>Contact</h5>
              <p>+216 73 000 000<br>hello@gourmethaven.tn</p>
            </div>
          </div>
        </div>
      </div>
      <form method="POST" class="form-panel">
        <input type="hidden" name="form_type" value="reservation">
        <input type="hidden" name="csrf_token" value="<?=generateCsrfToken()?>">
        <div class="form-row">
          <div class="field">
            <label>Full Name *</label>
            <input type="text" name="name" required value="<?=isLoggedIn()?htmlspecialchars($_SESSION['user_name']??''):''?>">
          </div>
          <div class="field">
            <label>Email *</label>
            <input type="email" name="email" required value="<?=isLoggedIn()?htmlspecialchars($_SESSION['user_email']??''):''?>">
          </div>
          <div class="field">
            <label>Phone</label>
            <input type="tel" name="phone">
          </div>
          <div class="field">
            <label>Date *</label>
            <input type="date" name="date" required min="<?=date('Y-m-d')?>">
          </div>
          <div class="field">
            <label>Time *</label>
            <input type="time" name="time" required>
          </div>
          <div class="field">
            <label>Number of Guests *</label>
            <input type="number" name="guests" min="1" max="20" value="2" required>
          </div>
          <div class="field full">
            <label>Special Requests</label>
            <textarea name="notes" rows="3"></textarea>
          </div>
        </div>
        <div class="submit-field">
          <button type="submit" class="btn-submit">Request Reservation</button>
        </div>
      </form>
    </div>
  </div>
</section>
 
<!-- MAP — SOUSSE -->
<section id="location">
  <div class="map-wrap">
    <div class="map-info reveal">
      <div class="section-label">Find Us</div>
      <h2><em>Nestled in the Heart</em><br>of Sousse</h2>
      <div class="map-info-list">
        <div class="map-info-item">
          <div class="map-icon">📍</div>
          <div class="map-icon-inner">
            <h5>Address</h5>
            <p>Avenue Habib Bourguiba<br>Sousse 4000, Tunisia</p>
          </div>
        </div>
        <div class="map-info-item">
          <div class="map-icon">🚗</div>
          <div class="map-icon-inner">
            <h5>Parking</h5>
            <p>Valet parking available<br>Public parking nearby</p>
          </div>
        </div>
        <div class="map-info-item">
          <div class="map-icon">✉️</div>
          <div class="map-icon-inner">
            <h5>Get in Touch</h5>
            <p><a href="mailto:hello@gourmethaven.tn">hello@gourmethaven.tn</a><br><a href="tel:+21673000000">+216 73 000 000</a></p>
          </div>
        </div>
        <div class="map-info-item">
          <div class="map-icon">🕐</div>
          <div class="map-icon-inner">
            <h5>Hours</h5>
            <p>Daily · 11:00 AM – 11:00 PM</p>
          </div>
        </div>
      </div>
    </div>
    <div id="soussemap"></div>
  </div>
</section>
 
<!-- OCR -->
<section id="ocr" class="section">
  <div class="container">
    <div class="reveal">
      <div class="section-label">Instant Recognition</div>
      <h2 class="section-title"><em>QuickScan</em> OCR</h2>
      <div class="ornament"><div class="ornament-diamond"></div></div>
    </div>
    <div class="ocr-box reveal">
      <div class="ocr-drop" id="ocrDrop">
        <div class="ocr-drop-icon">📸</div>
        <p>Drop an image here, or click to browse</p>
        <input type="file" id="ocrInput" accept="image/*">
      </div>
      <div class="ocr-controls">
        <button class="btn-gold" onclick="runOCR()">Scan Image</button>
        <button class="btn-outline" onclick="copyOCR()">Copy Text</button>
      </div>
      <div id="ocrStatus" class="ocr-status"></div>
      <textarea id="ocrOutput" rows="6" placeholder="Extracted text will appear here…"></textarea>
    </div>
  </div>
</section>
 
<footer>
  <div class="footer-inner">
    <a href="index.php" class="footer-logo">Gourmet Haven</a>
    <p>&copy; <?=date('Y')?> Gourmet Haven · Sousse, Tunisia. All rights reserved.</p>
  </div>
</footer>
 
<!-- CART MODAL -->
<div id="cartModal" class="modal">
  <div class="modal-box">
    <button class="modal-close" onclick="closeCart()">&times;</button>
    <h2>Your Order</h2>
    <div id="cartItems"></div>
    <div class="cart-total-row">Total: $<span id="cartTotal">0.00</span></div>
    <form method="POST" id="orderForm">
      <input type="hidden" name="form_type" value="order">
      <input type="hidden" name="csrf_token" value="<?=generateCsrfToken()?>">
      <input type="hidden" name="items_json" id="itemsJson">
      <?php if(!isLoggedIn()):?>
        <input type="text" name="customer_name" placeholder="Your Name" required class="oc">
        <input type="email" name="customer_email" placeholder="Your Email" required class="oc">
      <?php endif;?>
      <button type="submit" class="btn-gold">Place Order</button>
    </form>
  </div>
</div>
 
<!-- Tesseract -->
<script src="https://cdn.jsdelivr.net/npm/tesseract.js@4/dist/tesseract.min.js"></script>
<!-- Leaflet -->
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
 
<script>
/* ── CURSOR ───────────────────────────────── */
const dot=document.getElementById('cursorDot');
const ring=document.getElementById('cursorRing');
let mx=0,my=0,rx=0,ry=0;
document.addEventListener('mousemove',e=>{
  mx=e.clientX;my=e.clientY;
  dot.style.left=mx+'px';dot.style.top=my+'px';
});
function animateRing(){
  rx+=(mx-rx)*.12;ry+=(my-ry)*.12;
  ring.style.left=rx+'px';ring.style.top=ry+'px';
  requestAnimationFrame(animateRing);
}
animateRing();
document.querySelectorAll('a,button,.menu-card,.btn-add').forEach(el=>{
  el.addEventListener('mouseenter',()=>ring.classList.add('hovered'));
  el.addEventListener('mouseleave',()=>ring.classList.remove('hovered'));
});
 
/* ── NAV SCROLL ───────────────────────────── */
const navbar=document.getElementById('navbar');
window.addEventListener('scroll',()=>navbar.classList.toggle('scrolled',scrollY>60));
document.getElementById('navToggle').addEventListener('click',()=>{
  document.getElementById('navLinks').classList.toggle('open');
});
 
/* ── REVEAL ON SCROLL ─────────────────────── */
const ro=new IntersectionObserver(entries=>entries.forEach(e=>{
  if(e.isIntersecting)e.target.classList.add('visible');
}),{threshold:.1});
document.querySelectorAll('.reveal').forEach(el=>ro.observe(el));
 
/* ── CART ─────────────────────────────────── */
let cart=[];
function addToCart(id,name,price){
  const ex=cart.find(i=>i.id===id);
  if(ex)ex.qty++;
  else cart.push({id,name,price,qty:1});
  updateCartCount();
  const btn=event.currentTarget;
  btn.textContent='Added ✓';
  btn.style.background='var(--gold)';btn.style.color='var(--obsidian)';
  setTimeout(()=>{btn.textContent='Add';btn.style.background='';btn.style.color='';},1000);
}
function updateCartCount(){
  const n=cart.reduce((s,i)=>s+i.qty,0);
  document.getElementById('cartCount').textContent=n+' item'+(n!==1?'s':'')+' in cart';
}
function renderCart(){
  const el=document.getElementById('cartItems');
  if(!cart.length){el.innerHTML='<p style="color:var(--dust);font-size:.85rem;padding:.5rem 0">Your cart is empty.</p>';return;}
  el.innerHTML=cart.map(i=>`
    <div class="cart-item">
      <span class="cart-item-name">${i.name}<span class="cart-item-qty">×${i.qty}</span></span>
      <div class="cart-r">
        <span class="cart-price">$${(i.price*i.qty).toFixed(2)}</span>
        <button class="cart-rm" onclick="removeItem(${i.id})">✕</button>
      </div>
    </div>`).join('');
  const total=cart.reduce((s,i)=>s+i.price*i.qty,0);
  document.getElementById('cartTotal').textContent=total.toFixed(2);
  document.getElementById('itemsJson').value=JSON.stringify(cart);
}
function removeItem(id){cart=cart.filter(i=>i.id!==id);updateCartCount();renderCart();}
function openCart(){renderCart();document.getElementById('cartModal').classList.add('open');}
function closeCart(){document.getElementById('cartModal').classList.remove('open');}
document.getElementById('cartModal').addEventListener('click',e=>{if(e.target===e.currentTarget)closeCart();});
 
/* ── OCR ──────────────────────────────────── */
const ocrDrop=document.getElementById('ocrDrop');
ocrDrop.addEventListener('dragover',e=>{e.preventDefault();ocrDrop.classList.add('drag');});
ocrDrop.addEventListener('dragleave',()=>ocrDrop.classList.remove('drag'));
ocrDrop.addEventListener('drop',e=>{
  e.preventDefault();ocrDrop.classList.remove('drag');
  const f=e.dataTransfer.files[0];
  if(f)document.getElementById('ocrInput').files=e.dataTransfer.files;
});
async function runOCR(){
  const file=document.getElementById('ocrInput').files[0];
  const st=document.getElementById('ocrStatus');
  if(!file){st.textContent='Please select an image first.';return;}
  st.textContent='Initialising scanner…';
  const{data:{text}}=await Tesseract.recognize(file,'eng',{
    logger:m=>{if(m.status==='recognizing text')st.textContent='Scanning… '+Math.round(m.progress*100)+'%';}
  });
  document.getElementById('ocrOutput').value=text;
  st.textContent='✓ Scan complete.';
}
function copyOCR(){
  const t=document.getElementById('ocrOutput');
  t.select();document.execCommand('copy');
  document.getElementById('ocrStatus').textContent='✓ Copied to clipboard.';
}
 
/* ── LEAFLET MAP — SOUSSE ─────────────────── */
const map=L.map('soussemap',{
  center:[35.8288,10.6369],zoom:14,
  zoomControl:true,scrollWheelZoom:false,
  attributionControl:false
});
 
// Dark CartoDB tiles
L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png',{
  attribution:'© OpenStreetMap contributors © CARTO',
  subdomains:'abcd',maxZoom:20
}).addTo(map);
 
// Custom gold marker icon
const goldIcon=L.divIcon({
  className:'',
  html:`<div style="
    width:14px;height:14px;background:var(--gold);
    border-radius:50%;border:3px solid #fff;
    box-shadow:0 0 0 3px var(--gold),0 4px 20px rgba(201,168,76,.6);
    position:relative;
  "></div>
  <div style="
    position:absolute;top:18px;left:50%;transform:translateX(-50%);
    background:var(--gold);color:#060504;
    font-family:'Cinzel',serif;font-size:9px;font-weight:600;
    letter-spacing:.12em;padding:3px 10px;white-space:nowrap;
  ">GOURMET HAVEN</div>`,
  iconSize:[14,14],iconAnchor:[7,7],popupAnchor:[0,-20]
});
 
const marker=L.marker([35.8288,10.6369],{icon:goldIcon}).addTo(map);
marker.bindPopup(`
  <div style="font-family:'DM Sans',sans-serif;padding:.4rem">
    <div style="font-family:'Cinzel',serif;font-size:.72rem;letter-spacing:.15em;color:var(--gold);margin-bottom:.4rem">GOURMET HAVEN</div>
    <div style="color:var(--cream);font-size:.82rem;line-height:1.7">
      Avenue Habib Bourguiba<br>Sousse 4000, Tunisia<br>
      <span style="color:var(--dust)">+216 73 000 000</span>
    </div>
  </div>
`).openPopup();
 
// Attribution small
L.control.attribution({position:'bottomright',prefix:''}).addTo(map);
</script>
</body>
</html>