<?php
require 'db.php';
require 'functions.php';

if (!isLoggedIn()) {
    header('Location: login.php');
    exit;
}

$userId = $_SESSION['user_id'];
$email = $_SESSION['user_email'];

$otp = getUserOtpSecret($pdo, $userId);

if (!$otp) {
    die("No secret found. Run the SQL insert above first.");
}

$secret = $otp['secret'];
$uri = TOTP::getProvisioningUri($email, $secret);
$qrUrl = 'https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=' . urlencode($uri);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Setup QuickClock</title>
<link rel="stylesheet" href="style.css">
</head>
<body class="auth-page">
<div class="auth-box">
    <h2>Scan This QR Code</h2>
    <p>Open Google Authenticator and scan:</p>
    <div class="qr-wrap">
        <img src="<?= sanitize($qrUrl) ?>" alt="QR">
    </div>
    <p><strong>Secret:</strong> <?= sanitize($secret) ?></p>
    <p style="color:red">Save this secret. If you lose your phone, you need it.</p>
    <a href="logout.php" class="btn-primary full text-center">Logout & Login Again</a>
</div>
</body>
</html>