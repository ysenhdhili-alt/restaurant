<?php
require 'db.php';
require 'functions.php';

$email = 'YOUR_EMAIL@gmail.com'; // <-- CHANGE THIS

$stmt = $pdo->prepare("SELECT o.secret, o.enabled, o.verified 
                       FROM otp_secrets o 
                       JOIN users u ON o.user_id = u.id 
                       WHERE u.email = ?");
$stmt->execute([$email]);
$row = $stmt->fetch();

if (!$row) {
    die("NO SECRET FOUND for this email. Run the SQL above to reset.");
}

echo "<h2>Your Secret: " . $row['secret'] . "</h2>";
echo "<h1 style='color:red;font-size:40px'>Server Code NOW: " . TOTP::getCode($row['secret']) . "</h1>";
echo "<p>This changes every 30 seconds</p>";
echo "<hr>";
echo "<p>Now open your Authenticator app on your phone.</p>";
echo "<p>Does it show the SAME 6 digits right now?</p>";
echo "<p>If NO → your phone has the WRONG secret. Delete this entry from your phone and re-scan the QR from register.php</p>";