<?php
require 'db.php';
require 'functions.php';
requireAdmin();

$section = $_GET['section'] ?? 'menu';
$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && validateCsrfToken($_POST['csrf_token'] ?? '')) {
    $action = $_POST['action'] ?? '';

    if ($action === 'add_menu') {
        $name = trim($_POST['name'] ?? '');
        $desc = trim($_POST['description'] ?? '');
        $price = filter_var($_POST['price'] ?? 0, FILTER_VALIDATE_FLOAT);
        $cat = trim($_POST['category'] ?? '');
        $imgPath = '';

        if (!empty($_FILES['image']['tmp_name'])) {
            $allowed = ['image/jpeg', 'image/png', 'image/webp'];
            if (in_array($_FILES['image']['type'], $allowed) && $_FILES['image']['size'] < 2097152) {
                $ext = pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION);
                $fname = uniqid() . '.' . $ext;
                move_uploaded_file($_FILES['image']['tmp_name'], 'uploads/' . $fname);
                $imgPath = 'uploads/' . $fname;
            }
        }

        $stmt = $pdo->prepare("INSERT INTO menu_items (name, description, price, category, image_path) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([$name, $desc, $price, $cat, $imgPath]);
        $message = 'Menu item added.';
    }

    if ($action === 'delete_menu') {
        $stmt = $pdo->prepare("DELETE FROM menu_items WHERE id = ?");
        $stmt->execute([$_POST['id']]);
        $message = 'Menu item deleted.';
    }

    if ($action === 'update_reservation') {
        $stmt = $pdo->prepare("UPDATE reservations SET status = ? WHERE id = ?");
        $stmt->execute([$_POST['status'], $_POST['id']]);
        $message = 'Reservation updated.';
    }

    if ($action === 'update_order') {
        $stmt = $pdo->prepare("UPDATE orders SET status = ? WHERE id = ?");
        $stmt->execute([$_POST['status'], $_POST['id']]);
        $message = 'Order updated.';
    }

    if ($action === 'toggle_role') {
        $stmt = $pdo->prepare("UPDATE users SET role = IF(role='admin','customer','admin') WHERE id = ? AND id != ?");
        $stmt->execute([$_POST['id'], $_SESSION['user_id']]);
        $message = 'Role updated.';
    }

    if ($action === 'delete_user') {
        $stmt = $pdo->prepare("DELETE FROM users WHERE id = ? AND id != ?");
        $stmt->execute([$_POST['id'], $_SESSION['user_id']]);
        $message = 'User deleted.';
    }
}

$menuItems = $pdo->query("SELECT * FROM menu_items ORDER BY category, name")->fetchAll();
$reservations = $pdo->query("SELECT r.*, u.name as user_name FROM reservations r LEFT JOIN users u ON r.user_id = u.id ORDER BY r.created_at DESC")->fetchAll();
$orders = $pdo->query("SELECT o.*, u.name as user_name FROM orders o LEFT JOIN users u ON o.user_id = u.id ORDER BY o.created_at DESC")->fetchAll();
$users = $pdo->query("SELECT id, name, email, role, created_at FROM users ORDER BY created_at DESC")->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Dashboard | Gourmet Haven</title>
<link rel="stylesheet" href="style.css">
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700&family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
</head>
<body class="dashboard-body">

<aside class="sidebar">
    <h2>Admin Panel</h2>
    <nav>
        <a href="?section=menu" class="<?= $section==='menu'?'active':'' ?>">Menu</a>
        <a href="?section=reservations" class="<?= $section==='reservations'?'active':'' ?>">Reservations</a>
        <a href="?section=orders" class="<?= $section==='orders'?'active':'' ?>">Orders</a>
        <a href="?section=users" class="<?= $section==='users'?'active':'' ?>">Users</a>
        <a href="index.php">Back to Site</a>
        <a href="logout.php">Logout</a>
    </nav>
</aside>

<main class="dashboard-main">
    <?php if ($message): ?><div class="alert alert-success"><?= sanitize($message) ?></div><?php endif; ?>

    <?php if ($section === 'menu'): ?>
        <h2>Manage Menu</h2>
        <form method="POST" enctype="multipart/form-data" class="form-grid compact">
            <input type="hidden" name="action" value="add_menu">
            <input type="hidden" name="csrf_token" value="<?= generateCsrfToken() ?>">
            <div class="form-group"><input type="text" name="name" placeholder="Item Name" required></div>
            <div class="form-group"><input type="text" name="category" placeholder="Category" required></div>
            <div class="form-group"><input type="number" step="0.01" name="price" placeholder="Price" required></div>
            <div class="form-group"><input type="file" name="image" accept="image/*"></div>
            <div class="form-group full"><textarea name="description" placeholder="Description" rows="2"></textarea></div>
            <div class="form-group full"><button type="submit" class="btn-primary">Add Item</button></div>
        </form>

        <table class="data-table">
            <thead><tr><th>Image</th><th>Name</th><th>Category</th><th>Price</th><th>Action</th></tr></thead>
            <tbody>
                <?php foreach ($menuItems as $item): ?>
                <tr>
                    <td><?php if ($item['image_path']): ?><img src="<?= sanitize($item['image_path']) ?>" class="thumb"><?php else: ?>-<?php endif; ?></td>
                    <td><?= sanitize($item['name']) ?></td>
                    <td><?= sanitize($item['category']) ?></td>
                    <td>$<?= number_format($item['price'],2) ?></td>
                    <td>
                        <form method="POST" style="display:inline;">
                            <input type="hidden" name="csrf_token" value="<?= generateCsrfToken() ?>">
                            <input type="hidden" name="action" value="delete_menu">
                            <input type="hidden" name="id" value="<?= $item['id'] ?>">
                            <button class="btn-danger" onclick="return confirm('Delete?')">Delete</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

    <?php elseif ($section === 'reservations'): ?>
        <h2>Reservations</h2>
        <table class="data-table">
            <thead><tr><th>ID</th><th>Name</th><th>Date</th><th>Time</th><th>Guests</th><th>Status</th><th>Update</th></tr></thead>
            <tbody>
                <?php foreach ($reservations as $r): ?>
                <tr>
                    <td><?= $r['id'] ?></td>
                    <td><?= sanitize($r['name']) ?></td>
                    <td><?= $r['reservation_date'] ?></td>
                    <td><?= $r['reservation_time'] ?></td>
                    <td><?= $r['guests'] ?></td>
                    <td><span class="badge badge-<?= $r['status'] ?>"><?= $r['status'] ?></span></td>
                    <td>
                        <form method="POST" class="inline-form">
                            <input type="hidden" name="csrf_token" value="<?= generateCsrfToken() ?>">
                            <input type="hidden" name="action" value="update_reservation">
                            <input type="hidden" name="id" value="<?= $r['id'] ?>">
                            <select name="status">
                                <option value="pending" <?= $r['status']==='pending'?'selected':'' ?>>Pending</option>
                                <option value="confirmed" <?= $r['status']==='confirmed'?'selected':'' ?>>Confirmed</option>
                                <option value="cancelled" <?= $r['status']==='cancelled'?'selected':'' ?>>Cancelled</option>
                                <option value="completed" <?= $r['status']==='completed'?'selected':'' ?>>Completed</option>
                            </select>
                            <button class="btn-secondary">Save</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

    <?php elseif ($section === 'orders'): ?>
        <h2>Orders</h2>
        <table class="data-table">
            <thead><tr><th>ID</th><th>Customer</th><th>Items</th><th>Total</th><th>Status</th><th>Update</th></tr></thead>
            <tbody>
                <?php foreach ($orders as $o): 
                    $items = json_decode($o['items_json'], true);
                ?>
                <tr>
                    <td><?= $o['id'] ?></td>
                    <td><?= sanitize($o['customer_name']) ?></td>
                    <td>
                        <?php foreach ($items as $it): ?>
                            <div><?= ($it['qty']??1) ?>x <?= sanitize($it['name']) ?></div>
                        <?php endforeach; ?>
                    </td>
                    <td>$<?= number_format($o['total_amount'],2) ?></td>
                    <td><span class="badge badge-<?= $o['status'] ?>"><?= $o['status'] ?></span></td>
                    <td>
                        <form method="POST" class="inline-form">
                            <input type="hidden" name="csrf_token" value="<?= generateCsrfToken() ?>">
                            <input type="hidden" name="action" value="update_order">
                            <input type="hidden" name="id" value="<?= $o['id'] ?>">
                            <select name="status">
                                <option value="pending" <?= $o['status']==='pending'?'selected':'' ?>>Pending</option>
                                <option value="preparing" <?= $o['status']==='preparing'?'selected':'' ?>>Preparing</option>
                                <option value="ready" <?= $o['status']==='ready'?'selected':'' ?>>Ready</option>
                                <option value="delivered" <?= $o['status']==='delivered'?'selected':'' ?>>Delivered</option>
                                <option value="cancelled" <?= $o['status']==='cancelled'?'selected':'' ?>>Cancelled</option>
                            </select>
                            <button class="btn-secondary">Save</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

    <?php elseif ($section === 'users'): ?>
        <h2>Manage Users</h2>
        <table class="data-table">
            <thead><tr><th>ID</th><th>Name</th><th>Email</th><th>Role</th><th>Joined</th><th>Actions</th></tr></thead>
            <tbody>
                <?php foreach ($users as $u): ?>
                <tr>
                    <td><?= $u['id'] ?></td>
                    <td><?= sanitize($u['name']) ?></td>
                    <td><?= sanitize($u['email']) ?></td>
                    <td><?= $u['role'] ?></td>
                    <td><?= $u['created_at'] ?></td>
                    <td>
                        <form method="POST" style="display:inline;">
                            <input type="hidden" name="csrf_token" value="<?= generateCsrfToken() ?>">
                            <input type="hidden" name="action" value="toggle_role">
                            <input type="hidden" name="id" value="<?= $u['id'] ?>">
                            <button class="btn-secondary">Toggle Role</button>
                        </form>
                        <?php if ($u['id'] != $_SESSION['user_id']): ?>
                        <form method="POST" style="display:inline;">
                            <input type="hidden" name="csrf_token" value="<?= generateCsrfToken() ?>">
                            <input type="hidden" name="action" value="delete_user">
                            <input type="hidden" name="id" value="<?= $u['id'] ?>">
                            <button class="btn-danger" onclick="return confirm('Delete this user?')">Delete</button>
                        </form>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
</main>

</body>
</html>
