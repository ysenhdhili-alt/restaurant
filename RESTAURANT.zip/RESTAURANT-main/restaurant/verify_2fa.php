<?php
date_default_timezone_set("Africa/Tunis");
require 'db.php';
require 'functions.php';

if (!isset($_SESSION['pending_user_id'])) {
    header('Location: login.php');
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!validateCsrfToken($_POST['csrf_token'] ?? '')) {
        $error = 'Invalid security token.';
    } elseif (!checkOtpRateLimit()) {
        $error = 'Too many attempts. Please wait 5 minutes.';
    } else {
        $code = preg_replace('/\s+/', '', $_POST['code'] ?? '');
        $userId = $_SESSION['pending_user_id'];
        $otpRecord = getUserOtpSecret($pdo, $userId);

        if (!$otpRecord) {
            $error = '2FA configuration error.';
        } else {
            $valid = false;

            // Check TOTP code (window = 2 gives ±60 seconds tolerance)
            if (TOTP::verifyCode($otpRecord['secret'], $code, 2)) {
                $valid = true;
            } else {
                // Check backup codes
                $backups = json_decode($otpRecord['backup_codes'] ?? '[]', true);
                $newBackups = [];
                foreach ($backups as $hash) {
                    if (!$valid && password_verify($code, $hash)) {
                        $valid = true;
                        continue; // Remove used backup code
                    }
                    $newBackups[] = $hash;
                }
                if ($valid) {
                    $upd = $pdo->prepare("UPDATE otp_secrets SET backup_codes = ? WHERE user_id = ?");
                    $upd->execute([json_encode($newBackups), $userId]);
                }
            }

            if ($valid) {
                if (!$otpRecord['verified']) {
                    $upd = $pdo->prepare("UPDATE otp_secrets SET verified = 1, enabled = 1 WHERE user_id = ?");
                    $upd->execute([$userId]);
                }

                $_SESSION['user_id'] = $userId;
                $_SESSION['user_name'] = $_SESSION['pending_user_name'];
                $_SESSION['user_email'] = $_SESSION['pending_user_email'];
                $_SESSION['role'] = $_SESSION['pending_user_role'];

                unset(
                    $_SESSION['pending_user_id'],
                    $_SESSION['pending_user_name'],
                    $_SESSION['pending_user_email'],
                    $_SESSION['pending_user_role']
                );

                session_regenerate_id(true);
                header('Location: ' . ($_SESSION['role'] === 'admin' ? 'dashboard.php' : 'index.php'));
                exit;
            } else {
                recordOtpAttempt();
                $error = 'Invalid code. Please try again.';
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Verify 2FA | Gourmet Haven</title>
<link rel="stylesheet" href="style.css">
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700&family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
</head>
<body class="auth-page">

<div class="auth-box">
    <h2>QuickClock Verification</h2>
    <p class="text-center">Enter the 6-digit code from your authenticator app or a backup code.</p>
    <?php if ($error): ?><div class="alert alert-error"><?= sanitize($error) ?></div><?php endif; ?>
    <form method="POST">
        <input type="hidden" name="csrf_token" value="<?= generateCsrfToken() ?>">
        <div class="form-group">
            <label>Authentication Code</label>
            <input type="text" name="code" required pattern="[0-9a-zA-Z]{6,8}" autocomplete="off" autofocus>
        </div>
        <button type="submit" class="btn-primary full">Verify</button>
    </form>
</div>

</body>
</html>